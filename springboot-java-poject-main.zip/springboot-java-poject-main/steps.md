## https://www.youtube.com/@devopsshack
## Learn DevOps in 30 Days at https://www.youtube.com/watch?v=9q1DnI8MoIE&list=PLAdTNzDIZj_8BerYwx-rUjmVkj6A9vD9_&pp=gAQBiAQB
## To Build & Run This project, follow the steps.

--> Clone the Project

--> Go to Root directly of the project

--> Run "mvn clean package"

--> Run "java -jar target/jar_file_name.jar"

--> Access the Application at IP:8080
